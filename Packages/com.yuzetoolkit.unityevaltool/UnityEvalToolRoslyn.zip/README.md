# UnityEvalToolRoslyn

Roslyn source generator for `com.yuzetoolkit.unityevaltool`.

The generator reads C# tool classes marked with `YuzeToolkit.EvalToolAttribute` and methods marked with `YuzeToolkit.EvalFunctionAttribute`, then emits the partial `IEvalTool` metadata implementation used by `EvalToolRegistry`.

## Build

```bash
dotnet test Packages/UnityEvalToolRoslyn/UnityEvalToolRoslyn.sln
dotnet build Packages/UnityEvalToolRoslyn/src/UnityEvalTool.SourceGenerator/UnityEvalTool.SourceGenerator.csproj -c Release
```

Unity uses the deployed analyzer DLL at:

```text
Packages/com.yuzetoolkit.unityevaltool/Analyzers/UnityEvalTool.SourceGenerator.dll
```

After rebuilding, copy the release DLL to that path and keep the `.meta` file with the `RoslynAnalyzer` label.
